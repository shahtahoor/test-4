package com.examphotostudio.app.data

data class ExamPreset(
    val id: String,
    val name: String,
    val authority: String,
    val photoWidthCm: Float,
    val photoHeightCm: Float,
    val photoDpi: Int = 300,
    val photoMinKb: Int,
    val photoMaxKb: Int,
    val signatureWidthCm: Float,
    val signatureHeightCm: Float,
    val signatureMinKb: Int,
    val signatureMaxKb: Int,
    val backgroundRequirement: String = "White"
)

object ExamPresetsRepository {
    val presets: List<ExamPreset> = listOf(
        ExamPreset(
            id = "neet-pg",
            name = "NEET PG",
            authority = "NBEMS (National Board)",
            photoWidthCm = 3.5f,
            photoHeightCm = 4.5f,
            photoMinKb = 20,
            photoMaxKb = 50,
            signatureWidthCm = 3.5f,
            signatureHeightCm = 1.5f,
            signatureMinKb = 10,
            signatureMaxKb = 20,
            backgroundRequirement = "White (#FFFFFF)"
        ),
        ExamPreset(
            id = "ini-cet",
            name = "INI-CET (AIIMS/JIPMER)",
            authority = "AIIMS New Delhi",
            photoWidthCm = 3.5f,
            photoHeightCm = 4.5f,
            photoMinKb = 50,
            photoMaxKb = 100,
            signatureWidthCm = 6.0f,
            signatureHeightCm = 3.0f,
            signatureMinKb = 20,
            signatureMaxKb = 100,
            backgroundRequirement = "White background"
        ),
        ExamPreset(
            id = "upsc-cse",
            name = "UPSC Civil Services",
            authority = "Union Public Service Commission",
            photoWidthCm = 4.0f,
            photoHeightCm = 4.0f,
            photoMinKb = 20,
            photoMaxKb = 300,
            signatureWidthCm = 4.0f,
            signatureHeightCm = 4.0f,
            signatureMinKb = 20,
            signatureMaxKb = 300,
            backgroundRequirement = "Plain light background"
        ),
        ExamPreset(
            id = "ssc-cgl",
            name = "SSC CGL / CHSL",
            authority = "Staff Selection Commission",
            photoWidthCm = 3.5f,
            photoHeightCm = 4.5f,
            photoMinKb = 20,
            photoMaxKb = 50,
            signatureWidthCm = 4.0f,
            signatureHeightCm = 2.0f,
            signatureMinKb = 10,
            signatureMaxKb = 20,
            backgroundRequirement = "White background"
        ),
        ExamPreset(
            id = "ibps-po",
            name = "IBPS PO / Clerk / SBI",
            authority = "Institute of Banking Personnel",
            photoWidthCm = 3.5f,
            photoHeightCm = 4.5f,
            photoMinKb = 20,
            photoMaxKb = 50,
            signatureWidthCm = 4.0f,
            signatureHeightCm = 2.0f,
            signatureMinKb = 10,
            signatureMaxKb = 20,
            backgroundRequirement = "White background"
        ),
        ExamPreset(
            id = "jee-main",
            name = "JEE Main / NEET UG",
            authority = "National Testing Agency (NTA)",
            photoWidthCm = 3.5f,
            photoHeightCm = 4.5f,
            photoMinKb = 10,
            photoMaxKb = 200,
            signatureWidthCm = 3.5f,
            signatureHeightCm = 1.5f,
            signatureMinKb = 4,
            signatureMaxKb = 30,
            backgroundRequirement = "White / Off-White"
        )
    )
}
