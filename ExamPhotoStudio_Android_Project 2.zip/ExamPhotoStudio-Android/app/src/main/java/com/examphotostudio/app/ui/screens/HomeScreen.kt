package com.examphotostudio.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.examphotostudio.app.ui.navigation.Destinations

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Exam Photo Studio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Offline Exam Preparation Suite",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                // Banner
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "100% Offline & Private",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Photos and documents never leave your phone. Zero cloud dependencies.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Core Studios",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                HomeToolCard(
                    title = "Photo Studio",
                    description = "Crop to exact mm/cm, set 300 DPI, compress to 20-50 KB range with instant verification.",
                    icon = Icons.Default.PhotoCamera,
                    badge = "Primary",
                    onClick = { navController.navigate(Destinations.PHOTO_STUDIO) }
                )
            }

            item {
                HomeToolCard(
                    title = "Signature Studio",
                    description = "Crop signature, auto-clean whitespace, ink contrast enhancement, export 10-20 KB.",
                    icon = Icons.Default.Draw,
                    onClick = { navController.navigate(Destinations.SIGNATURE_STUDIO) }
                )
            }

            item {
                HomeToolCard(
                    title = "Document Studio",
                    description = "Certificate & mark sheet scanner, corner perspective correction, B&W high-contrast filter.",
                    icon = Icons.Default.Description,
                    onClick = { navController.navigate(Destinations.DOCUMENT_STUDIO) }
                )
            }

            item {
                HomeToolCard(
                    title = "PDF Studio",
                    description = "Multi-image to PDF, page sizing (A4/Letter), PDF to JPG extraction, page reordering.",
                    icon = Icons.Default.PictureAsPdf,
                    onClick = { navController.navigate(Destinations.PDF_STUDIO) }
                )
            }

            item {
                Text(
                    text = "Smart Utilities",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                HomeToolCard(
                    title = "Background Remover",
                    description = "One-tap background segmentation to white (#FFFFFF), light blue or transparent PNG.",
                    icon = Icons.Default.AutoFixHigh,
                    onClick = { navController.navigate(Destinations.BG_REMOVER) }
                )
            }

            item {
                HomeToolCard(
                    title = "Image Quality Checker",
                    description = "Audit blur, exposure, DPI, resolution and exam criteria before submission.",
                    icon = Icons.Default.CheckCircle,
                    onClick = { navController.navigate(Destinations.QUALITY_CHECKER) }
                )
            }

            item {
                HomeToolCard(
                    title = "Exam Presets",
                    description = "Official guidelines for NEET PG, INI-CET, UPSC CSE, SSC, IBPS, and JEE Main.",
                    icon = Icons.Default.Bookmarks,
                    onClick = { navController.navigate(Destinations.PRESETS) }
                )
            }

            item {
                HomeToolCard(
                    title = "Recent Files",
                    description = "Quick access to your exported photos, signatures and generated PDFs.",
                    icon = Icons.Default.History,
                    onClick = { navController.navigate(Destinations.RECENT_FILES) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun HomeToolCard(
    title: String,
    description: String,
    icon: ImageVector,
    badge: String? = null,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = badge,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
