package com.examphotostudio.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examphotostudio.app.data.ExamPresetsRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresetsScreen(onBack: () -> Unit) {
    val presets = ExamPresetsRepository.presets

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Exam Presets Directory", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(presets) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(text = p.authority, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Photo: ${p.photoWidthCm} x ${p.photoHeightCm} cm | ${p.photoMinKb}-${p.photoMaxKb} KB", fontSize = 13.sp)
                        Text(text = "Signature: ${p.signatureWidthCm} x ${p.signatureHeightCm} cm | ${p.signatureMinKb}-${p.signatureMaxKb} KB", fontSize = 13.sp)
                        Text(text = "Background: ${p.backgroundRequirement}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
