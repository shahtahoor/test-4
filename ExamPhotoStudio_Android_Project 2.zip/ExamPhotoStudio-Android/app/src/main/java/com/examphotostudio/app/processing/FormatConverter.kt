package com.examphotostudio.app.processing

import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

object FormatConverter {

    enum class OutputFormat(val extension: String, val mimeType: String) {
        JPEG("jpg", "image/jpeg"),
        PNG("png", "image/png"),
        WEBP("webp", "image/webp")
    }

    suspend fun convertFormat(
        bitmap: Bitmap,
        targetFormat: OutputFormat,
        quality: Int = 95
    ): ByteArray = withContext(Dispatchers.Default) {
        val stream = ByteArrayOutputStream()
        when (targetFormat) {
            OutputFormat.JPEG -> bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            OutputFormat.PNG -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            OutputFormat.WEBP -> {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSY, quality, stream)
                } else {
                    @Suppress("DEPRECATION")
                    bitmap.compress(Bitmap.CompressFormat.WEBP, quality, stream)
                }
            }
        }
        stream.toByteArray()
    }
}
