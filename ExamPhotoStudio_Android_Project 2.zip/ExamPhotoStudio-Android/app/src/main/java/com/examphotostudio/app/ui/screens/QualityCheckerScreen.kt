package com.examphotostudio.app.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examphotostudio.app.processing.QualityChecker
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QualityCheckerScreen(onBack: () -> Unit) {
    val coroutineScope = rememberCoroutineScope()
    var currentBmp by remember { mutableStateOf<Bitmap?>(null) }
    var report by remember { mutableStateOf<QualityChecker.QualityReport?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp ->
        if (bmp != null) {
            currentBmp = bmp
            coroutineScope.launch {
                report = QualityChecker.analyzeQuality(bmp)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Quality Checker", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                if (currentBmp != null) {
                    Image(
                        bitmap = currentBmp!!.asImageBitmap(),
                        contentDescription = "Audit image",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Box(contentAlignment = Alignment.Center) {
                        Text("Select or capture an image to audit")
                    }
                }
            }

            Button(
                onClick = { photoLauncher.launch() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Camera, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Capture Image to Analyze")
            }

            if (report != null) {
                val r = report!!
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Quality Audit Findings", fontWeight = FontWeight.Bold)
                        Text("• Resolution: ${r.resolutionText}")
                        Text("• Sharpness: ${if (r.isSharp) "Sharp & Clear" else "Blurry"}")
                        Text("• Exposure: ${r.exposureStatus}")

                        if (r.warnings.isNotEmpty()) {
                            Text("Warnings:", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                            r.warnings.forEach { w ->
                                Text("  - $w", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
