package com.examphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examphotostudio.app.processing.ImageCompressor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var docBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var filterType by remember { mutableStateOf("B&W Clean") }

    val scanLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp ->
        if (bmp != null) {
            docBitmap = bmp
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Document Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                if (docBitmap != null) {
                    Image(
                        bitmap = docBitmap!!.asImageBitmap(),
                        contentDescription = "Document Scan",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Certificates, Marksheets, ID Proofs")
                    }
                }
            }

            Button(
                onClick = { scanLauncher.launch() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Scan Document with Camera")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Original", "B&W Clean", "Grayscale", "Readability Boost").forEach { f ->
                    FilterChip(
                        selected = filterType == f,
                        onClick = { filterType = f },
                        label = { Text(f, fontSize = 11.sp) }
                    )
                }
            }

            Button(
                onClick = {
                    Toast.makeText(context, "Exported 100-300 KB compliant document", Toast.LENGTH_SHORT).show()
                },
                enabled = docBitmap != null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export Document (100–300 KB PDF / JPG)")
            }
        }
    }
}
