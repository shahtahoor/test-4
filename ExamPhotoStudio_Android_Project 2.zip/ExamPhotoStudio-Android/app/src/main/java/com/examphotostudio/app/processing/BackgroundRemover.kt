package com.examphotostudio.app.processing

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sqrt

/**
 * On-device background segmentation and replacement for examination requirements (white/light blue/grey/transparent).
 */
object BackgroundRemover {

    enum class TargetBackground(val color: Int, val label: String) {
        WHITE(Color.WHITE, "Pure White (#FFFFFF)"),
        LIGHT_BLUE(Color.rgb(227, 242, 253), "Light Blue"),
        LIGHT_GREY(Color.rgb(245, 245, 245), "Light Grey"),
        TRANSPARENT(Color.TRANSPARENT, "Transparent PNG")
    }

    suspend fun replaceBackground(
        source: Bitmap,
        targetBg: TargetBackground,
        tolerance: Float = 35f
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height
        val output = source.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(width * height)
        output.getPixels(pixels, 0, width, 0, 0, width, height)

        // Sample background from top corners and top border
        val cornerColors = mutableListOf<Int>()
        for (x in 0 until minOf(20, width)) {
            cornerColors.add(pixels[x])
            cornerColors.add(pixels[width - 1 - x])
        }

        val threshold = tolerance * 2.2f

        for (i in pixels.indices) {
            val pixel = pixels[i]
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)

            var minDistance = Float.MAX_VALUE
            for (bg in cornerColors) {
                val bgR = Color.red(bg)
                val bgG = Color.green(bg)
                val bgB = Color.blue(bg)
                val dist = sqrt((r - bgR) * (r - bgR) * 0.3f + (g - bgG) * (g - bgG) * 0.59f + (b - bgB) * (b - bgB) * 0.11f)
                if (dist < minDistance) minDistance = dist
            }

            if (minDistance < threshold) {
                pixels[i] = targetBg.color
            }
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        output
    }
}
