package com.examphotostudio.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.examphotostudio.app.ui.screens.HomeScreen
import com.examphotostudio.app.ui.screens.PhotoStudioScreen
import com.examphotostudio.app.ui.screens.SignatureStudioScreen
import com.examphotostudio.app.ui.screens.DocumentStudioScreen
import com.examphotostudio.app.ui.screens.PdfStudioScreen
import com.examphotostudio.app.ui.screens.BackgroundRemoverScreen
import com.examphotostudio.app.ui.screens.QualityCheckerScreen
import com.examphotostudio.app.ui.screens.PresetsScreen
import com.examphotostudio.app.ui.screens.RecentFilesScreen

object Destinations {
    const val HOME = "home"
    const val PHOTO_STUDIO = "photo_studio"
    const val SIGNATURE_STUDIO = "signature_studio"
    const val DOCUMENT_STUDIO = "document_studio"
    const val PDF_STUDIO = "pdf_studio"
    const val BG_REMOVER = "bg_remover"
    const val QUALITY_CHECKER = "quality_checker"
    const val PRESETS = "presets"
    const val RECENT_FILES = "recent_files"
}

@Composable
fun ExamStudioAppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Destinations.HOME
    ) {
        composable(Destinations.HOME) {
            HomeScreen(navController = navController)
        }
        composable(Destinations.PHOTO_STUDIO) {
            PhotoStudioScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.SIGNATURE_STUDIO) {
            SignatureStudioScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.DOCUMENT_STUDIO) {
            DocumentStudioScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.PDF_STUDIO) {
            PdfStudioScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.BG_REMOVER) {
            BackgroundRemoverScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.QUALITY_CHECKER) {
            QualityCheckerScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.PRESETS) {
            PresetsScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.RECENT_FILES) {
            RecentFilesScreen(onBack = { navController.popBackStack() })
        }
    }
}
