package com.examphotostudio.app.processing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object CropAndResizeEngine {

    /**
     * Converts physical millimeters to pixels given DPI.
     */
    fun mmToPx(mm: Float, dpi: Int = 300): Int {
        return ((mm / 25.4f) * dpi).toInt().coerceAtLeast(1)
    }

    /**
     * Converts physical centimeters to pixels given DPI.
     */
    fun cmToPx(cm: Float, dpi: Int = 300): Int {
        return mmToPx(cm * 10f, dpi)
    }

    /**
     * Performs crop with exact bounds.
     */
    fun cropBitmap(source: Bitmap, left: Int, top: Int, width: Int, height: Int): Bitmap {
        val safeLeft = left.coerceIn(0, source.width - 1)
        val safeTop = top.coerceIn(0, source.height - 1)
        val safeWidth = width.coerceIn(1, source.width - safeLeft)
        val safeHeight = height.coerceIn(1, source.height - safeTop)
        return Bitmap.createBitmap(source, safeLeft, safeTop, safeWidth, safeHeight)
    }

    /**
     * Rescales a bitmap to exact target dimensions.
     */
    fun resizeExact(source: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        return Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
    }

    /**
     * Adds an examination bottom banner with candidate Name and Date of Taking (DOT).
     */
    fun addExamNameAndDateBanner(
        source: Bitmap,
        candidateName: String,
        dateOfTaking: String
    ): Bitmap {
        val output = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val bannerHeight = (output.height * 0.16f).toInt()
        val bannerTop = output.height - bannerHeight

        val bannerPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, bannerTop.toFloat(), output.width.toFloat(), output.height.toFloat(), bannerPaint)

        val borderPaint = Paint().apply {
            color = Color.DKGRAY
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(0f, bannerTop.toFloat(), output.width.toFloat(), bannerTop.toFloat(), borderPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = (bannerHeight * 0.35f)
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val centerX = output.width / 2f
        val line1Y = bannerTop + (bannerHeight * 0.42f)
        val line2Y = bannerTop + (bannerHeight * 0.85f)

        canvas.drawText(candidateName.uppercase(), centerX, line1Y, textPaint)
        textPaint.textSize = (bannerHeight * 0.28f)
        textPaint.isFakeBoldText = false
        canvas.drawText("D.O.P: $dateOfTaking", centerX, line2Y, textPaint)

        return output
    }
}
