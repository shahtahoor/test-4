package com.examphotostudio.app.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Standard Android SDK PDF Engine for offline PDF-to-image and Image-to-PDF conversion.
 * Uses native android.graphics.pdf without bulky external C++ libraries.
 */
object PdfEngine {

    enum class PageSize(val widthPt: Int, val heightPt: Int, val label: String) {
        A4(595, 842, "A4 (210 x 297 mm)"),
        A5(420, 595, "A5 (148 x 210 mm)"),
        LETTER(612, 792, "US Letter (8.5 x 11 in)")
    }

    /**
     * Converts a collection of Bitmaps into a multi-page PDF document.
     */
    suspend fun createPdfFromBitmaps(
        bitmaps: List<Bitmap>,
        outputFile: File,
        pageSize: PageSize = PageSize.A4,
        marginPt: Int = 36
    ): Boolean = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        for (i in bitmaps.indices) {
            val bitmap = bitmaps[i]
            val pageInfo = PdfDocument.PageInfo.Builder(pageSize.widthPt, pageSize.heightPt, i + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            val availableW = pageSize.widthPt - (marginPt * 2)
            val availableH = pageSize.heightPt - (marginPt * 2)

            val scale = minOf(
                availableW.toFloat() / bitmap.width,
                availableH.toFloat() / bitmap.height
            )

            val drawW = (bitmap.width * scale).toInt()
            val drawH = (bitmap.height * scale).toInt()
            val left = marginPt + (availableW - drawW) / 2
            val top = marginPt + (availableH - drawH) / 2

            val destRect = Rect(left, top, left + drawW, top + drawH)
            canvas.drawBitmap(bitmap, null, destRect, null)
            document.finishPage(page)
        }

        var success = false
        try {
            val out = FileOutputStream(outputFile)
            document.writeTo(out)
            out.flush()
            out.close()
            success = true
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            document.close()
        }

        success
    }

    /**
     * Renders pages from a PDF file into Bitmaps.
     */
    suspend fun renderPdfPagesToBitmaps(
        context: Context,
        pdfUri: Uri,
        maxPages: Int = 10
    ): List<Bitmap> = withContext(Dispatchers.IO) {
        val bitmaps = mutableListOf<Bitmap>()
        try {
            val fileDescriptor: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(pdfUri, "r")
            if (fileDescriptor != null) {
                val renderer = PdfRenderer(fileDescriptor)
                val count = minOf(renderer.pageCount, maxPages)
                for (i in 0 until count) {
                    val page = renderer.openPage(i)
                    val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                    page.close()
                }
                renderer.close()
                fileDescriptor.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        bitmaps
    }
}
