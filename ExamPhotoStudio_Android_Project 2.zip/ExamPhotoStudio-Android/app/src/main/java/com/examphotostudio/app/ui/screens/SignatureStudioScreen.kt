package com.examphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examphotostudio.app.processing.CropAndResizeEngine
import com.examphotostudio.app.processing.ImageCompressor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignatureStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var minKb by remember { mutableIntStateOf(10) }
    var maxKb by remember { mutableIntStateOf(20) }
    var isProcessing by remember { mutableStateOf(false) }
    var resultText by remember { mutableStateOf<String?>(null) }

    val captureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp ->
        if (bmp != null) {
            signatureBitmap = bmp
            resultText = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Signature Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                if (signatureBitmap != null) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = signatureBitmap!!.asImageBitmap(),
                            contentDescription = "Signature Preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Capture or choose signature on white paper", fontSize = 13.sp)
                    }
                }
            }

            Button(
                onClick = { captureLauncher.launch() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Capture Signature with Camera")
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Auto Ink Contrast & Trim Whitespace", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Ensures deep black/blue ink against clean white background as mandated by examination boards.", fontSize = 12.sp)
                }
            }

            Button(
                onClick = {
                    val bmp = signatureBitmap ?: return@Button
                    isProcessing = true
                    coroutineScope.launch {
                        // Standard exam signature: 3.5cm x 1.5cm or 4cm x 2cm
                        val targetW = CropAndResizeEngine.cmToPx(3.5f, 300)
                        val targetH = CropAndResizeEngine.cmToPx(1.5f, 300)
                        val resized = CropAndResizeEngine.resizeExact(bmp, targetW, targetH)
                        val comp = ImageCompressor.compressToRange(resized, minKb, maxKb)
                        resultText = "Processed: ${"%.1f".format(comp.actualSizeKb)} KB (Target: $minKb-$maxKb KB)"
                        isProcessing = false
                        Toast.makeText(context, resultText, Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = signatureBitmap != null && !isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Process & Export Signature (10–20 KB)")
            }

            if (resultText != null) {
                Text(text = resultText!!, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
    }
}
