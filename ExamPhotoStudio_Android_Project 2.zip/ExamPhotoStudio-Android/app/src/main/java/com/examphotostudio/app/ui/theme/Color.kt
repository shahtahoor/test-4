package com.examphotostudio.app.ui.theme

import androidx.compose.ui.graphics.Color

val SkyBluePrimary = Color(0xFF0284C7)
val SkyBlueDark = Color(0xFF0369A1)
val SkyBlueLight = Color(0xFFE0F2FE)
val SkyBlueAccent = Color(0xFF38BDF8)

val Slate900 = Color(0xFF0F172A)
val Slate700 = Color(0xFF334155)
val Slate500 = Color(0xFF64748B)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)
