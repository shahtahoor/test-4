package com.examphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examphotostudio.app.data.ExamPresetsRepository
import com.examphotostudio.app.processing.CropAndResizeEngine
import com.examphotostudio.app.processing.ImageCompressor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedPresetIndex by remember { mutableIntStateOf(0) }
    var minKb by remember { mutableIntStateOf(20) }
    var maxKb by remember { mutableIntStateOf(50) }
    var compressionResult by remember { mutableStateOf<ImageCompressor.CompressionResult?>(null) }
    var isProcessing by remember { mutableStateOf(false) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bmp: Bitmap? ->
        if (bmp != null) {
            currentBitmap = bmp
            compressionResult = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Photo Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Source Image Preview
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                if (currentBitmap != null) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = currentBitmap!!.asImageBitmap(),
                            contentDescription = "Current Photo",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No photograph selected", fontWeight = FontWeight.Medium)
                        Text("Capture or choose from gallery", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Capture & Select Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { takePictureLauncher.launch() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Take Photo")
                }
            }

            // Exam Presets selector
            Text("Preset Sizing (Physical mm / cm @ 300 DPI)", fontWeight = FontWeight.SemiBold)
            val presets = ExamPresetsRepository.presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.take(3).forEachIndexed { index, p ->
                    FilterChip(
                        selected = selectedPresetIndex == index,
                        onClick = {
                            selectedPresetIndex = index
                            minKb = p.photoMinKb
                            maxKb = p.photoMaxKb
                        },
                        label = { Text(p.name, fontSize = 12.sp) }
                    )
                }
            }

            // Range KB Adjustment
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Target KB Range: $minKb KB – $maxKb KB", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Calculated automatically for official examination portal acceptance.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Compression & Crop Actions
            Button(
                onClick = {
                    val bmp = currentBitmap ?: return@Button
                    isProcessing = true
                    coroutineScope.launch {
                        val p = presets[selectedPresetIndex]
                        val targetW = CropAndResizeEngine.cmToPx(p.photoWidthCm, p.photoDpi)
                        val targetH = CropAndResizeEngine.cmToPx(p.photoHeightCm, p.photoDpi)
                        val resized = CropAndResizeEngine.resizeExact(bmp, targetW, targetH)
                        val result = ImageCompressor.compressToRange(resized, minKb, maxKb)
                        compressionResult = result
                        isProcessing = false
                        Toast.makeText(context, "Compressed: ${"%.1f".format(result.actualSizeKb)} KB", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = currentBitmap != null && !isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Icon(imageVector = Icons.Default.Compress, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Resize & Compress to Exact Exam KB")
                }
            }

            // Result Card
            if (compressionResult != null) {
                val res = compressionResult!!
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (res.isCompliant) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (res.isCompliant) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (res.isCompliant) "Exam Compliance: 100%" else "Size Non-Compliant",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = res.message, fontSize = 13.sp)
                        Text(text = "Final Size: ${"%.1f".format(res.actualSizeKb)} KB (Quality: ${res.qualityUsed}%)", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
