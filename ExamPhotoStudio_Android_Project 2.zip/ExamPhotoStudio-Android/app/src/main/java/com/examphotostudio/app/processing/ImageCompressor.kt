package com.examphotostudio.app.processing

import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.abs

/**
 * High-precision iterative binary search JPEG compressor for strict exam size boundaries.
 */
object ImageCompressor {

    data class CompressionResult(
        val compressedBytes: ByteArray,
        val actualSizeKb: Float,
        val qualityUsed: Int,
        val isCompliant: Boolean,
        val reductionPercentage: Int,
        val message: String
    )

    suspend fun compressToRange(
        bitmap: Bitmap,
        minKb: Int,
        maxKb: Int,
        targetKb: Int = (minKb + maxKb) / 2
    ): CompressionResult = withContext(Dispatchers.Default) {
        val originalStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, originalStream)
        val originalSizeKb = originalStream.size() / 1024f

        var lowQuality = 5
        var highQuality = 98
        var bestQuality = 85
        var bestBytes: ByteArray = ByteArray(0)
        var bestDiff = Float.MAX_VALUE

        // 8 binary search iterations for fast and exact convergence
        for (i in 0 until 8) {
            val currentQ = (lowQuality + highQuality) / 2
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, currentQ, stream)
            val bytes = stream.toByteArray()
            val sizeKb = bytes.size / 1024f
            val diff = abs(sizeKb - targetKb)

            if (diff < bestDiff) {
                bestDiff = diff
                bestBytes = bytes
                bestQuality = currentQ
            }

            if (sizeKb > maxKb) {
                highQuality = currentQ - 1
            } else if (sizeKb < minKb) {
                lowQuality = currentQ + 1
            } else {
                if (sizeKb > targetKb) highQuality = currentQ - 1 else lowQuality = currentQ + 1
            }
        }

        val actualKb = bestBytes.size / 1024f
        val isCompliant = actualKb in minKb.toFloat()..maxKb.toFloat()
        val reduction = if (originalSizeKb > 0) {
            (((originalSizeKb - actualKb) / originalSizeKb) * 100).toInt().coerceAtLeast(0)
        } else 0

        val msg = when {
            actualKb > maxKb -> "File size ${"%.1f".format(actualKb)} KB exceeds upper limit of $maxKb KB."
            actualKb < minKb -> "File size ${"%.1f".format(actualKb)} KB is below minimum limit of $minKb KB."
            else -> "Size is compliant: ${"%.1f".format(actualKb)} KB at $bestQuality% quality."
        }

        CompressionResult(
            compressedBytes = bestBytes,
            actualSizeKb = actualKb,
            qualityUsed = bestQuality,
            isCompliant = isCompliant,
            reductionPercentage = reduction,
            message = msg
        )
    }
}
