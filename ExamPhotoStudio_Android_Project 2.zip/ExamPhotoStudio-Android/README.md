# Exam Photo Studio — Native Android Application

Offline-first photo, signature, document, and PDF preparation toolkit for competitive examinations (NEET PG, INI-CET, UPSC, SSC, Banking, JEE).

## Technology Stack
- **Language**: Kotlin 2.0.21
- **Android Gradle Plugin**: 8.6.1
- **Gradle Version**: 8.9
- **UI Toolkit**: Jetpack Compose (Material 3)
- **Architecture**: MVI / MVVM with Kotlin Coroutines
- **Min SDK**: API 26 (Android 8.0 Oreo)
- **Target SDK**: API 35 (Android 15)

## One-Click Automated APK Build via GitHub Actions
This project includes a ready-to-run GitHub Actions workflow in `.github/workflows/build-apk.yml`.
1. Create a new repository on GitHub (e.g. `exam-photo-studio`).
2. Push this project code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Exam Photo Studio"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/exam-photo-studio.git
   git push -u origin main
   ```
3. In GitHub, go to the **Actions** tab. The "Build Exam Photo Studio APK" workflow will run automatically.
4. When finished (typically under 2 minutes), download the compiled **ExamPhotoStudio-debug.apk** under the Artifacts section!

## Local Build Instructions (Android Studio / CLI)
1. Open Android Studio (Ladybug 2024.2+ recommended).
2. Choose **File > Open...** and select this directory.
3. Allow Gradle to sync.
4. Build APK via CLI:
   ```bash
   # Make gradlew executable if on Mac/Linux
   chmod +x gradlew

   # Build Debug APK
   ./gradlew assembleDebug

   # Output APK path:
   # app/build/outputs/apk/debug/app-debug.apk
   ```
